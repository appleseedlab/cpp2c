#define DONT_TRANSFORM x

int main(int argc, char const *argv[])
{
    int x = 0;
    DONT_TRANSFORM;
    return 0;
}
