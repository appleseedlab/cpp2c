#define DONT_TRANSFORM x

// 1 unique macro definition

int main(int argc, char const *argv[])
{
    int x = 0;
    DONT_TRANSFORM;
    return 0;
}
