#define DIGITBIT (1)
#define MASK(B) ((1) << (B))
#define testprop(c, p) ((c) & (p))
#define lisdigit(c) (testprop((c), (MASK(DIGITBIT))))

int main(int argc, char const *argv[])
{
    // 4 unique transformations
    lisdigit(DIGITBIT);
    return 0;
}
