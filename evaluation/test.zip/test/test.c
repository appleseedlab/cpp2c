int x = 0;

#define INNER x
#define MIDDLE INNER
#define OUTER MIDDLE

int main(int argc, char const *argv[])
{
    // 3 unique transformations
    OUTER;
    // 1 unique transformation
    OUTER;
    // 1 unique transformation
    MIDDLE;
    // 1 unique transformation
    MIDDLE;
    // 1 unique transformation
    INNER;
    // 1 unique transformation
    INNER;
    
    // 8 unique transformations total
    return 0;
}
